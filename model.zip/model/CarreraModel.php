<?php

require_once "Carrera.php";

/**
 * Clase que representa el modelo de la entidad Producto, heredando de la misma
 * 
 * @author Ing. Guillermo Rafael Vásquez Castaneda <memuxit@gmail.com>
 * @version 1.0
 */
class Carrera extends CarreraModel
{
    /**
     * Atributo de la clase
     *
     * @var string
     */
    private $tabla;

    /**
     * Constructor de la clase que a su vez, llama al constructor padre
     *
     * @param PDO conexion con la base de datos
     */
    public function __construct($datasource)
    {
        $this->tabla = "carreras";
        parent::__construct($datasource);
    }

    /**
     * Metodo que guarda un nuevo registro de la entidad Producto
     *
     * @return void
     */
    public function save()
    {
        $query = "INSERT INTO {$this->tabla} (nombre, duracion) VALUES (:nombre, :duracion)";
        $stmt = $this->datasource->prepare($query);
        $stmt->execute(array(":nombre" => $this->nombre, ":duracion" => $this->duracion));
    }

    /**
     * Metodo que modifica un registro de la entidad Producto
     *
     * @return void
     */
    public function update()
    {
        $query = "UPDATE {$this->tabla} SET nombre = :nombre, duracion = :duracion WHERE id = :id";
        $stmt = $this->datasource->prepare($query);
        $stmt->execute(array(":nombre" => $this->nombre, ":duracion" => $this->duracion, ":id" => $this->id));
    }

    /**
     * Metodo que devuelve un arreglo de registros de la entidad Producto
     *
     * @return array arreglo de objetos de la entidad Producto
     */
    public function all()
    {
        $carreras = array();
        $query = "SELECT * FROM {$this->tabla}";
        $stmt = $this->datasource->prepare($query);
        $stmt->execute();
        while ($Carrera = $stmt->fetch(PDO::FETCH_OBJ)) {
            array_push($carreras, $Carrera);
        }
        return $carreras;
    }
    public function find(int $id)
    {
        $query ="SELECT * FROM ($this->table) WHERE id =:id";
        $stmt  = $this->datasource->prepare($query);
        $stmt->execute(array(":id" == $id));
        return $stmt->fetch(PDO::FETCH_OBJ);
    }

    /**
     * Metodo que elimina un registro de la entidad Producto
     *
     * @param int id de la entidad a eliminar
     * @return void
     */
    public function delete($id)
    {
        $query = "DELETE FROM {$this->tabla} WHERE id = :id";
        $stmt = $this->datasource->prepare($query);
        $stmt->execute(array(":id" => $id));
    }
}