<!DOCTYPE html>
<html>
<head>
	<title>Modificar el producto </title>
	<meta charset="utf-8">
	<meta name ="viewport" content="width=device.width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
<h1>Modificar</h1>
	<form action="index.php?controles=Productos&action=Modificar" method="post" >
		<form action="" method="post" >
		<div class="row">
			<div class="col">
		<label for="nombre">Nombre: </label>
		<input type="text" name="nombre" id="nombre" required="" autofocus="">
	</div>
		<br>
		<br>
		<div class="row">
			<div class="col">
		<label for="apellidos">Apellidos </label>
		<input type="text" name="apellidos" id="apellidos" required="" autofocus="">
			</div>
		<br>
		<br>
		<div class="row">
			<div class="col">
		<label for = "pago_mes">Pago por mes</label>
		<input type="number" name="pago_mes" min="0.31" max="200" step="5"  required="required">
	</div>
		<br>
		<br>
		<div class="row">
			<div class="col">
		<labe for = "carrera"> Carrera </labe>
		<select name="carrera">

				<option>Tecnico en Sistemas informaticos</option>
				<option>Ingeneria en Mecatronica</option>
				<option>Doctorado en Medicina</option>
				<option>Profesorado</option>
				<option>Tecnico en Mecatronica Automotriz</option>
				<option selected></option>
			</select>
</div>

<button type="button" class="btn btn-info">Modificar</button>
</body>
</html>	